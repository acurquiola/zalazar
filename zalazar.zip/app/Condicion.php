<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Condicion extends Model
{
    protected $fillable = [
    	'descripcion' 
    ];
}
