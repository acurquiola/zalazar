<?php echo $__env->make('adm.novedades.galeria.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

					<a class="breadcrumb">Crear</a>
				</div>
				<form method="POST"  enctype="multipart/form-data" action="<?php echo e(action('ImagenController@store')); ?>" class="col s12 m8 offset-m2 xl10 offset-xl1">
					<?php echo e(csrf_field()); ?>


					<div class="row">
						<h5>Crear Galeria de la novedad <?php echo $novedad->nombre; ?></h5>					
						<div class="divider"></div>
						<div class="file-field input-field">
						<h6>Cargue las imágenes que conformarán la galería de la novedad</h6>
							<div class="btn">
								<span>Imágenes</span>
								<input type="file" multiple name="file_image[]">
								<span class="helper-text" data-error="wrong" data-success="right">Tamaño recomendado: 400x400 </span>
							</div>
							<label for=""></label>
							<div class="file-path-wrapper">
								<input class="file-path validate" type="text" placeholder="Cargue una o varias imágenes">
							</div>
						</div>
						<input type="hidden" name="novedad_id" value="<?php echo e($novedad->id); ?>">
						<div class="right">
							<a href="<?php echo e(action('NovedadController@index')); ?>" class="waves-effect waves-light btn">Cancelar</a>
							<button class="btn waves-effect waves-light" type="submit" name="action">Submit
								<i class="material-icons right">send</i>
							</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>

</main>



<?php echo $__env->make('adm.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>

	$(document).ready(function(){		

		M.AutoInit();
		$('.collapsible').collapsible();
		$('select').formSelect();  
	});

</script>


</body>

</html>