
Has recibido un pedido de : <?php echo e($cliente); ?>


<p>
Pedido nro: <?php echo e($pedido); ?>

</p>


<table class="center">
<thead>
  <tr>
      <th>Descripción</th>
      <th>Cantidad</th>
      <th>Monto</th>
  </tr>
</thead>

<tbody>
	<?php $__currentLoopData = $articulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  	  <tr>
	    <td><?php echo e($a->descripcion); ?></td>
	    <td><?php echo e($a->pivot->cantidad); ?></td>
	    <td><?php echo e($a->precio - $a->oferta); ?></td>
	  </tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
<tfoot>
	<tr>
		<td colspan="2">Total</td>
		<td><?php echo e($monto); ?></td>
	</tr>
</tfoot>
</table>

<p>
Mensaje: <?php echo e($mensaje); ?>

</p>