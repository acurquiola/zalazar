<?php $__env->startSection('content'); ?>


<body>

	<div class="privada" >
		
		<!-- Formulario  -->


		<div class="container">
			<?php if($pedidos->count() >0 ): ?>

			<div class="tabla-pedidos" style="margin-top: 5%">

				<table class="orden-table">

					<thead class="pedidos-table">

						<tr >


							<th>#</th>
							<th>FECHA</th>
							<th>MONTO</th>
							<th>STATUS</th>

						</tr>

					</thead>

					<tbody>

						<?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr >

							<td><?php echo e($p->id); ?></td>
							<td><?php echo e(Carbon\Carbon::parse($p->created_at)->format('d/m/Y')); ?></td>
							<td>$<?php echo e($p->monto_total); ?></td>
							<td><?php echo e(($p->status == 0)?'En Espera':'Confirmada'); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


					</tbody>
				</table>
			</div>
			<?php else: ?>
				<div class="center">
					
					<p>No ha realizado compras. </p>
					<a href="<?php echo e(action('SeccionProductoController@index')); ?>" class=" z-depth-0 btn button-continuar-compra center-align" id="estandar-otro-btn">VER PRODUCTOS</a>					

				</div>
			<?php endif; ?>


		</div>



		<?php $__env->stopSection(); ?>
	</div>

	<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</body>
</html>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>