<?php echo $__env->make('adm.productos.galeria.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
				</div>
				<div class="col s12">
					<div class="row">
						
						<h5>Galeria de Imágenes | Subfamilia: <?php echo $subfamilia->nombre; ?></h5>	

						<div class="right">
							<a href=" <?php echo e(action('GaleriaController@create', $subfamilia->id)); ?> " class="btn waves-effect waves-light orange"><i style="font-size: 15px" class="fas fa-plus-circle"></i>AGREGAR</a>
						</div>
					</div>

					<div class="divider"></div>

					<div class="col s12" style="margin-top: 5%">
						<table class="index-table responsive-table ">
							<thead>
								<tr>
									<th>Imagen</th>
									<th>Opciones</th>
								</tr>
							</thead>
							<tbody>
								<?php $__empty_1 = true; $__currentLoopData = $subfamilia->galerias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

									<tr>
										<td style="width: 350px"><img src=" <?php echo e(asset('images/galeria_productos/'.$g->file_image)); ?> " alt=""></td>
										<td>								
											<a href=" <?php echo e(action('GaleriaController@edit', $g->id)); ?> " class="btn-floating btn waves-effect waves-light orange"><i style="font-size: 15px" class="fas fa-pencil-alt"></i></a>
											<a onclick="return confirm('¿Realmente desea eliminar este registro?')"  href="<?php echo e(action('GaleriaController@eliminar', $g->id)); ?>" class="btn-floating btn waves-effect waves-light teal"><i class="material-icons">delete</i></a>
										</td>
									</tr>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

									<tr>
										<td colspan="3">No se consiguieron registros</td>
									</tr>
										
								<?php endif; ?>
							</tbody>
						</table>
					</div>
					<div class="row">					
						<div class="right" style="padding: 2%">
							<a href="<?php echo e(action('SubfamiliaController@index')); ?>" class="waves-effect waves-light btn">Volver</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

</main>



<?php echo $__env->make('adm.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<script>

	$(document).ready(function(){		

		M.AutoInit();
		$('.collapsible').collapsible();
		$('select').formSelect();  



	});

</script>



</body>

</html>