<?php echo $__env->make('adm.datos.contacto.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

				</div>

				<h5>Información de Contacto</h5>					
				<div class="divider" style="margin-bottom: 10px"></div>
				<form method="POST"  enctype="multipart/form-data" action="<?php echo e(action('DatoController@update', $datos->id)); ?>" class="col s12 m8 offset-m2 xl10 offset-xl1">
					<?php echo e(csrf_field()); ?>    
					<?php echo e(method_field('PUT')); ?>  

					<div class="row">
						<div class="input-field col s12">
							<i class="material-icons prefix">keyboard_arrow_right</i>
							<input id="icon_prefix" type="text" class="validate" name="descripcion" value="<?php echo e($datos->descripcion); ?>" >
							<label for="icon_prefix"><?php echo e(mb_strtoupper($datos->tipo)); ?></label>
						</div>
						<div class="right">
							<a href="<?php echo e(action('DatoController@contacto')); ?>" class="waves-effect waves-light btn">Cancelar</a>
							<button class="btn waves-effect waves-light" type="submit" name="action" value="contacto">Submit
								<i class="material-icons right">send</i>
							</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>



</main>



<?php echo $__env->make('adm.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<script>

	$(document).ready(function(){		
		M.AutoInit();
		$('.collapsible').collapsible();
		$('select').formSelect();  

	});
	
</script>


</body>

</html>