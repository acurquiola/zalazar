<?php echo $__env->make('adm.productos.subfamilias.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

				</div>

				<h5>Subfamilias</h5>					
				<div class="divider"></div>
				<table class="index-table-logos responsive-table mdl-data-table hover" id="table"  style="width:100%">
					<thead>
						<tr>
							<th>Orden</th>
							<th>Imagen</th>
							<th>Nombre</th>
							<th>Familia</th>
							<th>Ficha</th>
							<th>Opciones</th>
						</tr>
					</thead>
					<tbody>
						<?php $__empty_1 = true; $__currentLoopData = $subfamilias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td><?php echo e($f->orden); ?></td>
								<td><img src="<?php echo e(asset('images/subfamilias/'.$f->file_image)); ?>"></td>
								<td ><?php echo e($f->nombre); ?></td>
								<td><?php echo e($f->familia->nombre); ?></td>
								<td><?php echo e(($f->file_ficha != null)?'SÍ':'NO'); ?></td>
								<td>
									<a href=" <?php echo e(action('SubfamiliaController@edit', $f->id)); ?> " class="btn-floating btn waves-effect waves-light orange"><i style="font-size: 15px;" class="fas fa-pencil-alt"></i></a>										
									<a href=" <?php echo e(action('GaleriaController@index', ['id' => $f->id, 'tipo' => 'productos'])); ?>" class="btn-floating btn waves-effect waves-light teal"><i title="Ver galeria de imágenes" class="material-icons">photo_library</i></a>
									<a onclick="return confirm('¿Realmente desea eliminar este registro?')"  href=" <?php echo e(action('SubfamiliaController@eliminar', $f->id)); ?> " class="btn-floating btn waves-effect waves-light deep-orange"><i style="font-size: 15px;" class="fas fa-trash-alt"></i></a>

								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<tr>
								<td colspan="5">No existen registros</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>

			</div>
		</div>
	</div>



</main>



<?php echo $__env->make('adm.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<script>



	$(document).ready(function(){		
		M.AutoInit();
		$('.collapsible').collapsible();
		$('select').formSelect();  

	});
</script>


</body>

</html>