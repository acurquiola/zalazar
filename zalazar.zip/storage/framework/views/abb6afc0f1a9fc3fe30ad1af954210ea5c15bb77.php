	<?php echo $__env->make('adm.usuarios.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

				</div>

				<h5>Usuarios</h5>					
				<div class="divider"></div>
				<table class="index-table responsive-table ">
					<thead>
						<tr>
							<th>Username</th>
							<th>Nombre</th>
							<th>Tipo</th>
							<th>Opciones</th>

						</tr>
					</thead>
					<tbody>
						<?php $__empty_1 = true; $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td><?php echo e($u->username); ?></td>
								<td><?php echo e($u->name); ?></td>
								<td><?php echo e(ucwords($u->tipo)); ?></td>
								<td>
									<a href=" <?php echo e(action('AdminController@edit', $u->id)); ?> " class="btn-floating btn-large waves-effect waves-light orange"><i class="fas fa-pencil-alt"></i></a>
									<a onclick="return confirm('¿Realmente desea eliminar este registro?')"  href=" <?php echo e(action('AdminController@eliminar', $u->id)); ?> " class="btn-floating btn-large waves-effect waves-light blue"><i class="fas fa-user-minus"></i></a>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<tr>
								<td colspan="4">No existen registros</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>

			</div>
		</div>
	</div>



</main>



<?php echo $__env->make('adm.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<script>



	$(document).ready(function(){		
		M.AutoInit();
		$('.collapsible').collapsible();
		$('select').formSelect();  

	});
</script>


</body>

</html>