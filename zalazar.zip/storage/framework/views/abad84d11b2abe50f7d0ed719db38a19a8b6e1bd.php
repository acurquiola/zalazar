
<div class="slider" id="slider-home">
	<ul class="slides">
		<?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		<li>
			<img src="<?php echo e(asset('images/sliders/'.$s->file_image)); ?>" class="img-responsive" style="position: absolute;"> 
			<img src="<?php echo e(asset('images/sliders/capa.png')); ?>" style="position: absolute; mix-blend-mode: multiply;">        
			<div class="caption center-align" id="caption-sliders" style="padding-top: 7%">
				<div id="titulo-caption">
					<?php echo $s->titulo; ?>

				</div>
				<div id="descripcion-caption">
					<?php echo $s->descripcion; ?>	
				</div>
			</div>
		</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		<?php endif; ?>
	</ul>
</div>


 