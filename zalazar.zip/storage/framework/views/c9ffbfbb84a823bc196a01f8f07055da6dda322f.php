<?php $__env->startSection('content'); ?>


<body>


	<?php echo $__env->make('page.partials.slider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="container" style="border-top: 3px solid #5C89C5">
		<div class="row">
			<div class="col s12" id="seccion-nombre">
				<span>Quiénes Somos</span>
			</div>

			<div class="col s12  m12 l6" id="descripcion-empresa">
				<?php echo $empresa->descripcion; ?>

			</div>
			<div class="col s12  m12 l6">
				<img src="<?php echo e(asset('images/empresa/'.$empresa->file_image)); ?>" class="responsive-img">
			</div>
		</div>

	</div>

	<?php $__env->stopSection(); ?>

	<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<script>
		$(document).ready(function(){  
			$('#slider-home').slider({
				height: 479,
			})
		});

	</script>
</body>
</html>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>