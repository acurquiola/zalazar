<?php $__env->startSection('content'); ?>


<body>

	<div class="privada">
		
		<!-- Formulario  -->


			<div class="container container-fluid" style="padding-top: 5%">
				<div class="row">
					
					<?php $__empty_1 = true; $__currentLoopData = $resultado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<div class="col s12 m12 l3 center">
							<div class="card z-depth-0" id="subfamilia">
								<div class="subfamilia-productos">
							        <div class="efecto  hide-on-med-and-down">
										<a href="<?php echo e(action('SeccionProductoController@showProducto', $s->subfamilia->id)); ?>">
											<img src="<?php echo e(asset('images/subfamilias/hover-subfamilias.png')); ?>" class="responsive-img" style="width: 100%; margin-left: 3%">	    
										</a>                
									</div>
									<a href="<?php echo e(action('SeccionProductoController@showProducto', $s->subfamilia->id)); ?>"><img src="<?php echo e(asset('images/subfamilias/'.$s->subfamilia->file_image)); ?>"></a>
								</div>
								<div class="card-content" id="image-subfamilias-card-content" style="height: 50px;" >
									<span class="card-title center" id="image-subfamilias-card-content-title"><?php echo e($s->descripcion); ?></span>
									<span class="card-title left precio-anterior" id="image-subfamilias-card-content-title">$<?php echo e($s->precio); ?></span>
									<span class="card-title right precio-actual" id="image-subfamilias-card-content-title">$<?php echo e($s->precio - $s->oferta); ?></span>
								</div>
							</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<p>
							No conseguimos productos relacionados a esta categoría
						</p>
					<?php endif; ?>
				</div>
			</div>


		<?php $__env->stopSection(); ?>
	</div>

	<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>