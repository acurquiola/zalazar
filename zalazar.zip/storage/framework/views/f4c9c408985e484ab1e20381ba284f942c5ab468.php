
	<div class="col s12 m12 l3">			
		<ul class="collapsible z-depth-0" id="productos-collapsible" data-collapsible="accordion">
			<?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li>
					<div class="collapsible-header valign-wrapper <?php echo e(($familia->id == $f->id)?'familia-active':''); ?> " 
						 style=" display: flex;justify-content: space-between; align-items: center;" 
						 id="productos-collapsible-header">
						 <a href="<?php echo e(action('SeccionProductoController@show', $f->id)); ?>" 
						 	style="color: #454545"><?php echo e($f->nombre); ?>

						 </a>  
						 <?php if($familia->id == $f->id): ?> 
						 	<i class="material-icons right valign-wrapper">keyboard_arrow_down</i>
						 <?php else: ?>  
						 	<i class="material-icons right valign-wrapper">keyboard_arrow_right</i>   
						 <?php endif; ?>
					</div>
					<?php $__currentLoopData = $subfamilias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($f->id == $s->familia_id): ?>
							<div class="collapsible-body valign-wrapper" id="productos-collapsible-body" 
								<?php if($familia->id == $f->id): ?> 
									style="display:block;"
								<?php endif; ?>>
								<a href="<?php echo e(action('SeccionProductoController@showProducto', $s->id)); ?>"
									<?php if($activo == $s->id): ?> 
										class="subfamilia-active" 
									<?php endif; ?>>
									<?php echo e(mb_strtoupper($s->nombre)); ?>

								</a>
							</div>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>


