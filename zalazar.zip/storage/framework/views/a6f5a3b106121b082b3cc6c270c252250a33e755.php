<?php echo $__env->make('adm.productos.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

				</div>

				<h5>Productos</h5>	
				<div class="right">
					<a href=" <?php echo e(action('ProductoController@carga')); ?> " class="btn waves-effect waves-light orange"><i style="font-size: 15px" class="fas fa-plus-circle"></i>CARGA MASIVA</a>
				</div>				
				<div class="divider"></div>
				<table class="index-table-logos responsive-table mdl-data-table hover" id="table"  style="width:100%">
					<thead>
						<tr>
							<th>Orden</th>
							<th>Código</th>
							<th>Descripción</th>
							<th>Familia</th>
							<th>Subfamilia</th>
							<th>Opciones</th>
						</tr>
					</thead>
					<tbody>
						<?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<tr>
								<td><?php echo e($p->orden); ?></td>
								<td><?php echo e($p->codigo); ?></td>
								<td><?php echo e($p->descripcion); ?></td>
								<td><?php echo e($p->familia->nombre); ?></td>
								<td><?php echo e($p->subfamilia->nombre); ?></td>
								<td>
									<a href=" <?php echo e(action('ProductoController@edit', $p->id)); ?> " class="btn-floating btn waves-effect waves-light orange"><i style="font-size: 15px" class="fas fa-pencil-alt"></i></a>
									<a onclick="return confirm('¿Realmente desea eliminar este registro?')"  href=" <?php echo e(action('ProductoController@eliminar', $p->id)); ?> " class="btn-floating btn waves-effect waves-light deep-orange"><i style="font-size: 15px" class="fas fa-trash-alt"></i></a>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<tr>
								<td colspan="6">No existen registros</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>

			</div>
		</div>
	</div>



</main>



<?php echo $__env->make('adm.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<script>



	$(document).ready(function(){		
		M.AutoInit();
		$('.collapsible').collapsible();
		$('select').formSelect();  

	});
</script>


</body>

</html>