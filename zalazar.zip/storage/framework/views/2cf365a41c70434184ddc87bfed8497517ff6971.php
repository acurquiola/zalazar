<?php echo $__env->make('adm.home.informacion.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


					<a class="breadcrumb">Editar</a>
				</div>

				<h5>Información</h5>					
				<div class="divider"></div>
				<div class="col s12">

					<form method="POST"  enctype="multipart/form-data" action="<?php echo e(action('HomeController@updateInformacion', $informacion->id)); ?>" class="col s12 m8 offset-m2 xl10 offset-xl1">
						<?php echo e(csrf_field()); ?>    
						<?php echo e(method_field('PUT')); ?>  

						<div class="row">
							<h5>Editar</h5>					
							<div class="divider"></div>
							<div class="row">
								<div class="file-field input-field s6">
									<div class="btn">
										<span>Imagen</span>
										<input type="file" name="file_image">            
									</div>
									<div class="file-path-wrapper">
										<input class="file-path validate" type="text">
										<span class="helper-text" data-error="wrong" data-success="right">Tamaño recomendado: 120x120</span>
									</div>
								</div>
							</div>
							
							<div class="row">
								<div class="input-field col s6">
									<i class="material-icons prefix">keyboard_arrow_right</i>
									<input id="icon_prefix" type="text" class="validate" name="titulo1"  readonly value="<?php echo e($informacion->titulo1); ?>" >
									<label for="icon_prefix">Título 1</label>
								</div>
								<div class="input-field col s6">
									<i class="material-icons prefix">keyboard_arrow_right</i>
									<input id="icon_prefix" type="text" class="validate" name="titulo2"  readonly value="<?php echo e($informacion->titulo2); ?>" >
									<label for="icon_prefix">Título 2</label>
								</div>
							</div>

							<div class="right">
								<a href="<?php echo e(action('HomeController@index')); ?>" class="waves-effect waves-light btn btn-color">Cancelar</a>
								<button class="btn waves-effect waves-light btn-color" type="submit" name="action">Submit
									<i class="material-icons right">send</i>
								</button>
							</div>
						</div>
					</form>

				</div>
			</div>
		</div>
	</div>
</main>

<?php echo $__env->make('adm.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script src="//cdn.ckeditor.com/4.7.3/full/ckeditor.js"></script>
<script>

	$(document).ready(function(){		
		M.AutoInit();
		$('.collapsible').collapsible();
		$('select').formSelect();  
	});
</script>


</body>

</html>