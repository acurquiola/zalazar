<?php echo $__env->make('adm.productos.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<a class="breadcrumb">Crear</a>
				</div>

				<h5>Productos</h5>
				<div class="right">
					<a href=" <?php echo e(action('ProductoController@carga')); ?> " class="btn waves-effect waves-light orange"><i style="font-size: 15px" class="fas fa-plus-circle"></i>CARGA MASIVA</a>
				</div>							
				<div class="divider"></div>
				<div class="col s12">

					<form method="POST"  enctype="multipart/form-data" action="<?php echo e(action('ProductoController@store')); ?>" class="col s12 m8 offset-m2 xl10 offset-xl1">
						<?php echo e(csrf_field()); ?>    

						<div class="row">
							<h5>Crear</h5>					
							<div class="divider"></div>

							<div class="input-field col s8">
								<i class="material-icons prefix">keyboard_arrow_right</i>
								<input id="icon_prefix" type="text" class="validate" name="descripcion">
								<label for="icon_prefix">Descripción</label>
							</div>

							<div class="input-field col s4">
								<i class="material-icons prefix">keyboard_arrow_right</i>
								<input id="icon_prefix" type="text" class="validate" name="codigo"  >
								<label for="icon_prefix">Código</label>
							</div>

							<div class="input-field col s8">
								<i class="material-icons prefix">keyboard_arrow_right</i>
								<select class="materialSelect" id="familia" name="familia_id" required>
									<option>Familia</option>
									<?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($f->id); ?>"><?php echo e(ucwords($f->nombre)); ?> </option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>


							<div class="input-field col s1 center" >
							    <p>
							      <label>
							        <input type="checkbox" id="check-oferta" value="0" />
							        <span></span>
							      </label>
							    </p>
							</div>

							<div class="input-field col s2">
								<input id="icon_prefix" type="text" class="validate oferta-input" name="oferta" disabled="disabled">
								<label for="icon_prefix">Oferta</label>
							</div>


							<div class="input-field col s8">
								<i class="material-icons prefix">keyboard_arrow_right</i>
								<select class="materialSelect" id="subfamilia" name="subfamilia_id">
								<option>Subfamilia</option>
									<?php $__currentLoopData = $subfamilias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($s->id); ?>"><?php echo e(ucwords($s->nombre)); ?> </option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
							<div class="input-field col s4">
								<i class="material-icons prefix">keyboard_arrow_right</i>
								<input id="icon_prefix" type="text" class="validate" name="orden"  >
								<label for="icon_prefix">Orden</label>
							</div>

						</div>
						<div class="row">
							

							<div class="right">
								<a href="<?php echo e(action('ProductoController@index')); ?>" class="waves-effect waves-light btn btn-color">Cancelar</a>
								<button class="btn waves-effect waves-light btn-color" type="submit" name="action">Submit
									<i class="material-icons right">send</i>
								</button>
							</div>
						</div>
					</form>

				</div>
			</div>
		</div>
	</div>
</main>

<?php echo $__env->make('adm.layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>

	$(document).ready(function(){		
		M.AutoInit();
		$('.collapsible').collapsible();
		$('select').formSelect();  


		$('#check-oferta').click(function(){
			var value = $(this).val();
			if(value == '1'){				
				$(this).val('0');
				$('.oferta-input').attr('disabled','disabled');
			}else{
				$(this).val('1');
				$('.oferta-input').removeAttr('disabled');
			}
		});
	});



	 $(document).on("change", '#familia', function () {
        var subfamiliasURL = "<?php echo e(url('adm/productos/select/subfamilias')); ?>";

        $.get(subfamiliasURL,
                {option: $(this).val()},
                function (data) {
                    var model = $('#subfamilia');
                    model.empty();
                    //model.append("<option value='1'>Ninguna</option>");
                    $.each(data, function (index, element) {
                        model.append("<option value='" + element.id + "'>" + element.nombre + "</option>");

                    });
                    $('select').formSelect();  

                }
        );

    });
</script>


</body>

</html>