<?php $__env->startSection('content'); ?>


	<div class="container container-fluid-secciones" id="productos-row" style="padding-top: 2%">
		<div class="breadcrumb-productos">
			<a href="<?php echo e(action('SeccionProductoController@index')); ?>">Productos</a> | <a href="<?php echo e(action('SeccionProductoController@show', $familia->id)); ?>"><?php echo e($familia->nombre); ?></a> | <a href="<?php echo e(action('SeccionProductoController@showProductos', $subfamilia->id)); ?>"><?php echo e($subfamilia->nombre); ?></a> 
		</div>

		<div class="row">
			
			<?php echo $__env->make('page.productos.partials.menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

			<div class="col s12 m12 l9">

				<?php $__empty_1 = true; $__currentLoopData = $subfamilias_productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<div class="col s12 m12 l4">
						<div class="card z-depth-0" id="subfamilia">
							<div class="subfamilia-productos">
						        <div class="efecto  hide-on-med-and-down">
									<a href="<?php echo e(action('SeccionProductoController@showProducto', $p->id)); ?>"><img src="<?php echo e(asset('images/familias/hover-familias.png')); ?>" class="responsive-img" style="width: 100%; margin-left: 3%">	    </a>                
								</div>
								<a href="<?php echo e(action('SeccionProductoController@showProducto', $p->id)); ?>"><img src="<?php echo e(asset('images/productos/'.$p->file_image)); ?>"></a>
							</div>
							<div class="card-content" id="image-subfamilias-card-content" style="height: 50px;" >
								<span class="card-title center" id="image-subfamilias-card-content-title"><?php echo e($p->nombre); ?></span>
							</div>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<p>
						No conseguimos productos relacionados a esta categoría
					</p>
				<?php endif; ?>
			</div>
		</div>



	</div>

<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
</body>
</html>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>