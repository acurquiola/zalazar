<?php $__env->startSection('content'); ?>


<body>

	<?php echo $__env->make('page.partials.slider', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>



	<?php if($destacados->count() > 0): ?>
		<div class="container container-fluid" style="border-top: 3px solid #5C89C5" >
			<div class="row">
				<div class="col s12" id="seccion-nombre">
					<span>Productos Destacados</span>
				</div>
				<?php $__currentLoopData = $destacados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col s12 m12 l3 center">
						<div class="card z-depth-0" id="subfamilia">
							<div class="subfamilia-productos">
						        <div class="efecto  hide-on-med-and-down">
									<a href="<?php echo e(action('SeccionProductoController@showProducto', $s->id)); ?>">
										<img src="<?php echo e(asset('images/subfamilias/hover-subfamilias.png')); ?>" 
											 class="responsive-img" 
											 style="width: 100%; margin-left: 3%">	    
									</a>                
								</div>
								<a href="<?php echo e(action('SeccionProductoController@showProducto', $s->id)); ?>">
									<img src="<?php echo e(asset('images/subfamilias/'.$s->subfamilia->file_image)); ?>"></a>
							</div>
							<div class="card-content" id="image-subfamilias-card-content" style="height: 50px;" >
								<span class="card-title center" id="image-subfamilias-card-content-title"><?php echo e($s->nombre); ?></span>
							</div>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<div class="row center">
				<a href="<?php echo e(action('SeccionProductoController@index')); ?>" style="margin-top: -5% !important" class=" z-depth-0 btn button-continuar-compra center-align" id="estandar-btn">VER PRODUCTOS</a>					
			</div>
		</div>
	<?php endif; ?>

	

	<?php if($informacion): ?>
		<div class="row" style="margin-bottom: 0px; height: 279px; position: relative; background-image:url(<?php echo e(url('images/home/'.$informacion->file_image)); ?>) ">
				<img src="<?php echo e(asset('images/home/capa_informacions.png')); ?> " style="position: absolute; width: 100%">
				<div class="col s12" style="position: absolute; width: 80%; margin-left: 10%; margin-top: 5%;">
					<div class="col s12 m2" >
						<img src="<?php echo e(asset('images/home/logo-1.png')); ?> ">
					</div>
					<div class="col s12 m4" >
						<div class="informacion-titulo-caption"><?php echo $informacion->titulo1; ?> </div>
					</div>
					<div class="col s12 m2" >
						<img src="<?php echo e(asset('images/home/logo-2.png')); ?> ">
					</div>
					<div class="col s12 m4">
						<div class="informacion-titulo-caption"><?php echo $informacion->titulo2; ?></div>
					</div>
				</div>
				
		</div>
	<?php endif; ?>




	<?php $__env->stopSection(); ?>

	<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


	<script>
		$(document).ready(function(){  
			$('#slider-home').slider({
				height: 479,
			})
		});
	</script>


</body>
</html>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>