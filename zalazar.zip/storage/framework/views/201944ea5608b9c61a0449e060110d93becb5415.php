<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('adm.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('adm.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<main>
	<div class="container" id="container-fluid">
		<div class="row">
			<?php if($errors->any()): ?>
			<div class="card-panel alert-error">
				<ul>
					<li><i class="material-icons">error_outline</i><b>ALERTA: </b></li>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?> </li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>

			<?php if(session('alert')): ?>
			<div class="card-panel alert-success">
				<ul>
					<li>ALERTA:
						<?php echo e(session('alert')); ?>				
					</li>
				</ul>
			</div>
			<?php endif; ?>

			<div class="col s12">
				<div class="col s12" id="breadcrumb-admin">
					<a href="<?php echo e(url('adm/home/' )); ?>" class="breadcrumb">Home</a>
					<a href="<?php echo e(url('adm/empresa/sliders/' )); ?>" class="breadcrumb">Sliders</a>