<?php $__env->startSection('content'); ?>


<body>

	<div class="privada" style="background: #F4F4F4">
		
		<!-- Formulario  -->


			<div class="container">
				<div class="row">
					<div class="col s12" id="seccion-nombre"  style="border-top: 3px solid #5C89C5; margin-top: 5%">
						<span style="text-transform: capitalize"><?php echo e((\Auth::user()->tipo)); ?> : <?php echo e($user->name); ?></span>
					</div>
				</div>

				<?php if($user->tipo == 'vendedor'): ?>

					<?php if($user->clientes->count() > 0): ?>

						<div class="row">
							
							<div class="col s12 m12 l6">

								<span id="titulo-cliente">Seleccione un cliente</span>
								
								<ul class="collection" id="clientes-collection">
									<?php $__currentLoopData = $user->clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<a class="collection-item" href="<?php echo e(action('SeccionPrivadaController@cliente', $c->id)); ?>"><?php echo e($c->name); ?></a>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>

							</div>
						</div>
					<?php endif; ?>

				<?php else: ?>

					<div class="center">
						
						<p>Bienvenido. </p>
						<a href="<?php echo e(action('SeccionProductoController@index')); ?>" class=" z-depth-0 btn button-continuar-compra center-align" id="estandar-otro-btn">VER PRODUCTOS</a>					

					</div>
				<?php endif; ?>
			</div>


		<?php $__env->stopSection(); ?>
	</div>

	<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>