<?php $__env->startSection('content'); ?>


<body>

	<div class="container container-fluid-secciones" style="margin-top: 5%">
		<div class="row" id="familias-row">
			
			<?php $__empty_1 = true; $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<div class="col s12 m12 l4">
					<div class="familia-productos">
				        <div class="efecto">
							<a href="<?php echo e(action('SeccionProductoController@show', $f->id)); ?>"><img src="<?php echo e(asset('images/familias/hover-familias.png')); ?>" class="responsive-img" style="width: 100%">	    </a>                
						</div>
						<img src="<?php echo e(asset('images/familias/'.$f->file_image)); ?>">
					</div>
					<div class="card-content center" id="image-familias-card-content" style="height: 50px; margin-bottom: 5%" >
						<span class="card-title center" id="image-familias-card-content-title"><?php echo e($f->nombre); ?></span>
					</div>
				</div>	
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<?php endif; ?>
		</div>
	</div>

	<?php $__env->stopSection(); ?>

	<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>