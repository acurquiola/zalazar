<?php $__env->startSection('content'); ?>


	<div class="container container-fluid-secciones" id="productos-row" style="padding-top: 2%">
		<div class="breadcrumb-productos">
			<a href="<?php echo e(action('SeccionProductoController@index')); ?>">Productos</a> | 
			<a href="<?php echo e(action('SeccionProductoController@show', $familia->id)); ?>"><?php echo e($familia->nombre); ?></a> | 
			<a href="<?php echo e(action('SeccionProductoController@showProductos', $subfamilia->id)); ?>"><?php echo e($subfamilia->nombre); ?></a> 
		</div>

		<div class="row">
			
				<?php if(auth()->guard()->guest()): ?>
					

					<?php echo $__env->make('page.productos.partials.menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>


					<div class="col s12 m12 l9">

							<div class="row">
								
								<div class="col s12 m12 l6" style="border: 1px solid #EFF2F7; border-radius: 5px"> 
									<div class="slider">
									    <ul class="slides">
								            <li>
				                				<img src="<?php echo e(asset('images/subfamilias/'.$subfamilia->file_image)); ?>" alt="">
				                			</li>

				                			<?php if($subfamilia->galerias->count() > 0): ?>
									            <?php $__currentLoopData = $subfamilia->galerias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									            <li>
					                				<img src="<?php echo e(asset('images/galeria_productos/'.$s->file_image)); ?>" alt="">
					                			</li>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php endif; ?>
									    </ul>
									</div>					
								</div>
								<div class="col s12 m12 l6">
									<p id="productos-show-nombre"><?php echo e($subfamilia->nombre); ?></p>

									<p id="productos-show-descripcion"><?php echo $subfamilia->descripcion; ?></p>
									<?php if($subfamilia->file_ficha != null): ?>
										<div class="row">
											<div class="col s12 left" >
												<a style="width: 154px" href="<?php echo e(route('productos-down', $subfamilia->file_ficha)); ?>"  class="waves-effect waves-light btn z-depth-0" id="estandar-btn">DESCARGAR PDF</a>
											</div>
										</div>
									<?php endif; ?>
								</div>
							</div>
							
							<?php if($subfamilia->productos->count() >0): ?>

								<div class="row">
									<div class="col s12" style="padding: 5%">	
										<span id="nombre-medidas">Medidas</span>				
										<div id="medidas-productos">
											<table class="striped">
												<thead class="center">
													<tr>
														<th class="center">
															Código
														</th>
														<th>
															Descripción
														</th>
														<th>
															
														</th>
													</tr>
												</thead>
												<tbody>
													<?php $__currentLoopData = $subfamilia->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<tr>
															<td class="codigo-td center">
																<?php echo e($p->codigo); ?>	
															</td>
															<td>
																<?php echo e($p->descripcion); ?>	
															</td>
															<td class="consulta-td">
																<a href="<?php echo e(action('SeccionContactoController@show', ['producto'=>$p->id])); ?>">CONSULTAR</a>
															</td>
														</tr>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</tbody>
											</table>

										</div>
									</div>
								</div>
							<?php endif; ?>
					</div>

				<?php endif; ?>

				<?php if($subfamilia->productos->count() >0): ?>


					<?php if(auth()->guard()->check()): ?>
						<?php if(\Auth::user()->tipo == 'vendedor' || \Auth::user()->tipo == 'cliente'): ?>

							<div class="col s12 m12 l3" style="margin-top: 5%">
								<img src="<?php echo e(asset('images/subfamilias/'.$subfamilia->file_image)); ?>" alt="">
							</div>

							<div class="col s12 m12 l9">
							
								<div class="row">
									<div class="col s12">	
										<div id="medidas-productos">
											<table class="striped">
												<thead class="center">
													<tr>
														<th class="center">
															Código
														</th>
														<th>
															Descripción
														</th>
														<th class="center">
															Precio
														</th>
														<th class="center">
															Cantidad
														</th>
														<th class="center">
															Agregar
														</th>
													</tr>
												</thead>
												<tbody>
													<?php $__currentLoopData = $subfamilia->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														
														<tr>
															<td class="codigo-td center">
																<?php echo e($p->codigo); ?>	
															</td>
															<td>
																<?php echo e($p->descripcion); ?>	
															</td>
															<td class="center">
																<?php echo e($p->precio - $p->oferta); ?>	
															</td>
															<td class="center">
																<input min="1" required class="cantidad" name="cantidad[]" data-id="<?php echo e($p->id); ?>" style="width: 30px" type="number" value="1">
																<input id="cantidad-<?php echo e($p->id); ?>" name="cantidad-<?php echo e($p->id); ?>" type="hidden" value="1" >
															</td>
															<td class="center ">
																<div <?php if(in_array($p->id, $carrito)): ?> 
																		class="icon-shop-green add-cart"
																	<?php else: ?> 
																		class="icon-shop add-cart"
																	<?php endif; ?>
																	data-id="<?php echo e($p->id); ?>" id="cart<?php echo e($p->id); ?>">
																	<a href="#"> 
																		<i <?php if(in_array($p->id, $carrito)): ?> 
																			class="far fa-check-circle"
																		<?php else: ?> 
																			class="fas fa-cart-plus"
																		<?php endif; ?>
																		style="font-size: 30px;"></i> 
																	</a>
																</div>
															</td>
														</tr>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</tbody>
											</table>

										</div>
									</div>
								</div>
							</div>

						<?php endif; ?>
					<?php endif; ?>
				<?php else: ?>

				
					<p>
						No conseguimos productos relacionados a esta categoría
					</p>

				<?php endif; ?>
		</div>



	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script>

	$(document).ready(function(){  
		$('.materialboxed').materialbox();
		$( ".miniatura-img" ).click(function() {
			var src = $(this).data("srcimage");
			$("#bg-imagen").attr("src", src);
		});



		$('.cantidad').on("change",function () {
			var cantidad = $(this).val();
			var id       = $(this).data('id');
		    $('#cantidad-'+id).text(cantidad);
		});

		$('.icon-shop').click(function() {

			var id       = $(this).data('id');
			var c        = $('#cantidad-'+id).val(); 
			var cantidad = $('#cantidad-'+id).text();
			console.log(c, cantidad);

			if(cantidad == null || cantidad == '' )
				cantidad = c;
			
			var addCart  = "<?php echo e(action('SeccionPrivadaController@store')); ?>";

	        $.ajax({
        		data: {id: id, cantidad: cantidad},
        		method: 'POST',
	        	url: addCart,
			  	headers: {
			    	'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			  	}
	        })
	        .always(function(response, status, responseObject){
        		if(response['status'] == 0){
				    $("i", '#cart'+id).toggleClass("fas fa-cart-plus far fa-check-circle");
				    $('#cart'+id).toggleClass("icon-shop icon-shop-green");
        		}
	        });
		});


		$('.icon-shop-green').click(function() {
			var id         = $(this).data('id');			
			var removeItem = "<?php echo e(action('SeccionPrivadaController@remover')); ?>";

	        $.ajax({
        		data:{id: id},
        		method: 'POST',
	        	url: removeItem,
			  	headers: {
			    	'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			  	}
	        })
	        .always(function(response, status, responseObject){
	        	console.log(response);
        		if(response['status'] == 0){
				    $("i", '#cart'+id).toggleClass("fas fa-cart-plus far fa-check-circle");
				    $('#cart'+id).toggleClass("icon-shop icon-shop-green");
        		}
	        });
		});


	});

</script>

</body>
</html>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>