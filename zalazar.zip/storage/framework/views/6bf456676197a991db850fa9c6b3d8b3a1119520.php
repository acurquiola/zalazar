<?php $__env->startSection('content'); ?>


<body>

<div class="container container-fluid">
	
	<div class="row">
		<div class="col s12" id="seccion-nombre" style="margin-top: 5%">
			<span>Novedades</span>
		</div>
		
		<div class="col s12 m12 l10">
		
			<?php $__currentLoopData = $novedades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col s12 m12 l5" style="margin-left: 5%">

					<ul class="tabs">
						<li class="tab col s5" 
							style="text-align: left !important">
							<a href="#" class="active titulo-tab-novedades"><?php echo e($n->clasificacion->nombre); ?></a>
						</li>
					</ul>
					<div class="card z-depth-0 hoverable" style="border-top: 4px solid #FFFFFF; margin-top: 0;">
						<a id="link-index-novedades" href="<?php echo e(route('ver', $n->id)); ?>" >
							<div class="card-image" >
								<img src="<?php echo e(asset('images/novedades/'.$n->file_image)); ?>">
							</div>
							<div class="card-stacked" style="background: #fafafa !important">
								<span class="card-title" style="margin-top: 5%" id="titulo-index-novedades"><?php echo e($n->titulo); ?></span>

								<div class="card-content" style="">
									<p  id="descripcion-index-novedades" ><?php echo e(substr($n->texto, 0, 130)); ?>...</p>
								</div>
							</div>
						</a>
					</div>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>

		<div class="col s12 m12 l2" style="margin-right: -10%">
			<p id="titulo-categorias">Categorías</p>
			<div class="divider" style="background: #B0B0B0;"></div>

			<ul class="collection" id="collection-novedades">
				<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		      		<a  href="<?php echo e(route('filtros', $c->id)); ?>" 
		      			class="collection-item" 
		      			id="collection-novedades-item">
		      				<i class="fas fa-angle-double-right" style="margin-right: 5%"></i>
		      			<?php echo e($c->nombre); ?>

		      		</a>
		      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    </ul>
		</div>
	</div>
		
</div>
	<?php $__env->stopSection(); ?>

	<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>