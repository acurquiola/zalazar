<?php $__env->startSection('content'); ?>


<body>

	<div class="contacto" style="background: #F4F4F4">
		
		<!-- Formulario  -->


			<div class="container">
				<div class="row">
					<div class="col s12" id="seccion-nombre"  style="border-top: 3px solid #5C89C5; margin-top: 5%">
						<span>Contacto</span>
					</div>
				</div>

				<?php echo $__env->make('page.contacto.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</div>


		<?php $__env->stopSection(); ?>
	</div>

	<?php echo $__env->make('layouts.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>



<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>